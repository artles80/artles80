<?PHP

class config{

	public $HostDB = "localhost";
	public $UserDB = "047160168_test";
	public $PassDB = "u;!j8frb632N";
	public $BaseDB = "9289008595_test";
	
}
?>