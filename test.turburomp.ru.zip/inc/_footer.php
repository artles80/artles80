
<div class="container ">
			




 <div class="row bg-success">
  <div class="col"></div>
  <div class="col"><center><h1> &copy; 2020 footer</h1></center></div>
  <div class="col"></div>
</div>



	

</div>

<script language="JavaScript" type="text/javascript">
setSelected('icon_main');
setSelected('icon_main_menu');
setSelected('icon_main_menu2');

</script>

</body>



</div>

	
</html>