
<html>
	<head>
		<title>test</title>
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
		<link href="/style/style.css" rel="stylesheet" type="text/css" />
		
		<!-- Required meta tags -->
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <!-- Bootstrap CSS -->
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">

	
	</head>
	<body >
	
       <div class="container ">
			
			<div class="row  bg-info">
		      <div class="col"></div>
		      <div class="col "><center><h3>Тестовое задание</h3></center></div>
		      <div class="col  "> <? if($_SESSION["admin"]==1){?><span class="float-right"><a href="/exit" class="tag">Выход </a></span> <?}
		      else{?><span class="float-right"><a href="/login" class="tag">Авторизация </a></span><?}?></div>
	    </div>
	   
         

					


    </div>   

      
     
     
          
       
      
      
       
       
     
           
     
      
    
  
					    
 
       				
    						
						