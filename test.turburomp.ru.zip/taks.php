<?PHP

	if(isset($_POST["email"])){
	    
	    $email = $func->IsMail($_POST["email"]);
	    $login = $func->IsLogin($_POST["login"]);
	    $text = $_POST["text"];
	    
	    	if($email !== false){
	    	    
	    	    
	    	    	if($login !== false){
	    	    	    
	    	    	    
	    	    	    if($tesx==""){
	    	    	        
	    	    	    }else echo "<center><b><font color = 'red'>Поле для задачи нужно заполнить.</font></b></center><BR />";
			
			
			       }else echo "<center><b><font color = 'red'>Логин заполнен неверно.</font></b></center><BR />";
			
			
			}else echo "<center><font color = 'red'><b>Email имеет неверный формат.</b></font></center>";
	}
	    
?>	    